
import './App.css';
import Aggidtutorial  from './AgGrid/Aggridtutorial'
function App() {
  return (
    <div className="App">
     <Aggidtutorial></Aggidtutorial>
    </div>
  );
}

export default App;
